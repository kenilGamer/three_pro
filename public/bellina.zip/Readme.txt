Hi There

Thank you for download my product.
This product FREE PERSONAL USE.
If you want the full version ( PUA Encode ) and license
for commercial use,
you can purchases here ;

https://www.myfonts.com/foundry/balevgraph-studio/
https://www.etsy.com/shop/Balevgraphstudio
https://fontbundles.net/balevgraph-studio
https://sofontsy.com/collections/balevgraph-studio
https://graphicriver.net/user/balevgraph-studio/portfolio
https://www.creativefabrica.com/designer/balevgraph-studio

Donate : paypal.me/iqbalpauji

More info : balevgraph.studio@gmail.com

Thank you.